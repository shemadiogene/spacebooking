<?php
  $connection=mysqli_connect("localhost","root","","c0tg41yy_darasa");

?>